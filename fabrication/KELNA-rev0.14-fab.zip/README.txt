KELNA rev 0.14
100 x 60 mm; two copper layers.
Project board thickness: 1.6 mm.
Gerber X2, metric, absolute origin; not mirrored.
Separate plated (PTH) and non-plated (NPTH) metric Excellon files.
3 mm upper/lower enclosure guide bands contain no copper.
Drill hits: 96 PTH, 4 NPTH, including 0 slots.
Source PCB SHA256: 0cc8eec82c00f3849e416c253a86ac800f20c74e3379d70aa55dc898aa4e317a
